Replace this file with main.c and mainUI.c and compile the program in this folder. Run the executable from within this folder.
Delete this folder if on Linux.
